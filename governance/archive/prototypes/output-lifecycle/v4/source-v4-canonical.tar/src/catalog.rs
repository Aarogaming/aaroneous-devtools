use crate::{Record, Result};
use rusqlite::{Connection, OptionalExtension, Transaction, TransactionBehavior, params};
use std::path::Path;

const RECORD_BYTES: usize = 2_097_152;

pub trait Catalog {
    fn get(&self, id: &str) -> Result<Option<Record>>;
    fn compare_and_set(&mut self, expected: Option<u64>, record: &Record) -> Result<()>;
    fn list(&self) -> Result<Vec<Record>>;
    fn search(&self, query: &str) -> Result<Vec<Record>> {
        if query.len() > 256 || query.chars().any(|c| c.is_control()) {
            return Err("invalid search query".into());
        }
        let query = query.to_lowercase();
        let mut matches = vec![];
        for record in self.list()? {
            if serde_json::to_string(&record)
                .map_err(|e| e.to_string())?
                .to_lowercase()
                .contains(&query)
            {
                matches.push(record);
            }
        }
        Ok(matches)
    }
}

pub struct SqliteCatalog {
    connection: Connection,
    capacity: usize,
}
impl SqliteCatalog {
    pub fn open(path: &Path, capacity: usize) -> Result<Self> {
        if capacity == 0 || capacity > 256 {
            return Err("catalog capacity must be 1..256".into());
        }
        let connection = Connection::open_with_flags(
            path,
            rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE
                | rusqlite::OpenFlags::SQLITE_OPEN_CREATE
                | rusqlite::OpenFlags::SQLITE_OPEN_NOFOLLOW,
        )
        .map_err(|e| e.to_string())?;
        connection
            .busy_timeout(std::time::Duration::ZERO)
            .map_err(|e| e.to_string())?;
        // Bound native row/string allocation as well as the Rust record body.
        connection
            .set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_LENGTH, 2_101_248)
            .map_err(|e| e.to_string())?;
        connection
            .set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_WORKER_THREADS, 0)
            .map_err(|e| e.to_string())?;
        connection.execute_batch("PRAGMA foreign_keys=ON; PRAGMA synchronous=FULL;
            CREATE TABLE IF NOT EXISTS catalog (id TEXT PRIMARY KEY, version INTEGER NOT NULL, body TEXT NOT NULL);")
            .map_err(|e| e.to_string())?;
        Self::check_capacity(&connection, capacity)?;
        Ok(Self {
            connection,
            capacity,
        })
    }
    fn check_capacity(connection: &Connection, capacity: usize) -> Result<()> {
        let count: i64 = connection
            .query_row("SELECT COUNT(*) FROM catalog", [], |r| r.get(0))
            .map_err(|e| e.to_string())?;
        if count > i64::try_from(capacity).map_err(|e| e.to_string())? {
            return Err("existing catalog exceeds configured capacity; no records hidden".into());
        }
        Ok(())
    }
    fn decode(row: &rusqlite::Row<'_>) -> Result<Record> {
        let stored_id = row
            .get_ref(0)
            .map_err(|e| e.to_string())?
            .as_str()
            .map_err(|e| e.to_string())?;
        let version: i64 = row.get(1).map_err(|e| e.to_string())?;
        let body = row
            .get_ref(2)
            .map_err(|e| e.to_string())?
            .as_str()
            .map_err(|e| e.to_string())?;
        // Borrow SQLite's bytes before deserialization; do not allocate an unbounded String.
        if stored_id.len() > 256 || body.len() > RECORD_BYTES {
            return Err("stored record exceeds byte budget".into());
        }
        let record: Record = serde_json::from_str(body).map_err(|e| e.to_string())?;
        if stored_id != record.artifact.id
            || version != i64::try_from(record.version).map_err(|e| e.to_string())?
        {
            return Err("catalog row ID/version disagrees with projection".into());
        }
        record.validate()?;
        Ok(record)
    }
    fn read(connection: &Connection, id: &str) -> Result<Option<Record>> {
        if id.len() > 256 || id.chars().any(|c| c.is_control()) {
            return Err("invalid catalog ID".into());
        }
        connection
            .query_row(
                "SELECT id,version,body FROM catalog WHERE id=?1",
                [id],
                |row| Ok(Self::decode(row)),
            )
            .optional()
            .map_err(|e| e.to_string())?
            .transpose()
    }
    fn read_all(connection: &Connection, capacity: usize) -> Result<Vec<Record>> {
        Self::check_capacity(connection, capacity)?;
        let mut stmt = connection
            .prepare("SELECT id,version,body FROM catalog ORDER BY id LIMIT ?1")
            .map_err(|e| e.to_string())?;
        let rows = stmt
            .query_map(
                [i64::try_from(capacity + 1).map_err(|e| e.to_string())?],
                |row| Ok(Self::decode(row)),
            )
            .map_err(|e| e.to_string())?;
        let mut records = Vec::new();
        for row in rows {
            records.push(row.map_err(|e| e.to_string())??);
        }
        if records.len() > capacity {
            return Err("catalog exceeds capacity; no truncated result".into());
        }
        Ok(records)
    }
}
impl Catalog for SqliteCatalog {
    fn get(&self, id: &str) -> Result<Option<Record>> {
        let tx = Transaction::new_unchecked(&self.connection, TransactionBehavior::Deferred)
            .map_err(|e| e.to_string())?;
        Self::check_capacity(&tx, self.capacity)?;
        let record = Self::read(&tx, id)?;
        tx.commit().map_err(|e| e.to_string())?;
        Ok(record)
    }
    fn compare_and_set(&mut self, expected: Option<u64>, record: &Record) -> Result<()> {
        record.validate()?;
        let body = serde_json::to_string(record).map_err(|e| e.to_string())?;
        if body.len() > RECORD_BYTES {
            return Err("stored record exceeds byte budget".into());
        }
        let tx = self
            .connection
            .transaction_with_behavior(TransactionBehavior::Immediate)
            .map_err(|e| e.to_string())?;
        Self::check_capacity(&tx, self.capacity)?;
        let previous = Self::read(&tx, &record.artifact.id)?;
        let version = previous.as_ref().map(|r| r.version);
        if let Some(previous) = previous
            && (previous.artifact != record.artifact
                || previous.policy != record.policy
                || !record.history.starts_with(&previous.history))
        {
            return Err(
                "catalog update must extend exact artifact, policy and retained history".into(),
            );
        }
        if version != expected {
            return Err("catalog version collision".into());
        }
        if version.is_none() {
            let count: i64 = tx
                .query_row("SELECT COUNT(*) FROM catalog", [], |r| r.get(0))
                .map_err(|e| e.to_string())?;
            if count >= i64::try_from(self.capacity).map_err(|e| e.to_string())? {
                return Err("catalog capacity reached".into());
            }
        } else if record.version <= version.ok_or("missing stored version")? {
            return Err("catalog update must advance version".into());
        }
        tx.execute(
            "INSERT INTO catalog(id,version,body) VALUES (?1,?2,?3)
            ON CONFLICT(id) DO UPDATE SET version=excluded.version,body=excluded.body",
            params![
                record.artifact.id,
                i64::try_from(record.version).map_err(|e| e.to_string())?,
                body
            ],
        )
        .map_err(|e| e.to_string())?;
        tx.commit().map_err(|e| e.to_string())
    }
    fn list(&self) -> Result<Vec<Record>> {
        let tx = Transaction::new_unchecked(&self.connection, TransactionBehavior::Deferred)
            .map_err(|e| e.to_string())?;
        let records = Self::read_all(&tx, self.capacity)?;
        tx.commit().map_err(|e| e.to_string())?;
        Ok(records)
    }
}

#[cfg(test)]
mod snapshot_tests {
    use super::*;
    #[test]
    fn read_transaction_keeps_capacity_and_rows_on_one_snapshot() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let path = sandbox.path().join("snapshot.db");
        let reader = SqliteCatalog::open(&path, 1).expect("reader");
        reader
            .connection
            .pragma_update(None, "journal_mode", "WAL")
            .expect("fixture WAL");
        let tx = Transaction::new_unchecked(&reader.connection, TransactionBehavior::Deferred)
            .expect("snapshot");
        SqliteCatalog::check_capacity(&tx, 1).expect("capture empty snapshot");
        let raw = Connection::open(&path).expect("separate writer");
        raw.execute("INSERT INTO catalog VALUES ('corrupt-fixture',0,'{}')", [])
            .expect("concurrent fixture write");
        assert!(
            SqliteCatalog::read_all(&tx, 1)
                .expect("same snapshot")
                .is_empty()
        );
        tx.commit().expect("commit read");
        assert!(reader.list().is_err());
    }
}
