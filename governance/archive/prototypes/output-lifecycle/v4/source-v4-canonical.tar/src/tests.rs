use super::*;
use crate::catalog::{Catalog, SqliteCatalog};

fn proof() -> Evidence {
    Evidence {
        path: "fixture.json".into(),
        sha256: "a".repeat(64),
    }
}
fn artifact() -> Artifact {
    Artifact {
        schema_version: 1,
        id: "fixture-M01".into(),
        kind: "reviewed_finding".into(),
        producer: "qwen".into(),
        contributors: vec!["co-writer".into()],
        source_revision: "fixture-r1".into(),
        original_verdict: "rejected".into(),
        profile: Profile::PrototypeTooling,
        evidence: vec![proof()],
    }
}
fn policy() -> Policy {
    Policy {
        max_attempts: 2,
        max_lease_ticks: 6,
    }
}
fn review(r: &Record, who: &str, disposition: Disposition) -> Review {
    Review {
        reviewer: who.into(),
        artifact_sha256: r.artifact_sha256.clone(),
        action_sha256: None,
        disposition,
        scope: "fixture-only lifecycle".into(),
        note: "Retained bounded review".into(),
        receipt: proof(),
    }
}
fn step(r: &Record, tick: u64, operation: Operation) -> Result<Record> {
    reduce(
        r,
        &Event {
            expected_version: r.version,
            tick,
            operation,
        },
        &policy(),
    )
}
fn ready() -> Record {
    let r = Record::new(artifact(), policy()).expect("fixture");
    let review = review(&r, "reviewer", Disposition::FollowUp);
    let r = step(&r, 1, Operation::Review { review }).expect("fixture review");
    step(
        &r,
        2,
        Operation::Plan {
            task: "Count lexical markers".into(),
            acceptance: "Matches declared array lengths".into(),
            destination: "steward-candidate-inbox".into(),
        },
    )
    .expect("fixture plan")
}
fn leased() -> Record {
    step(
        &ready(),
        3,
        Operation::Lease {
            seat: "operator".into(),
            token: "lease-1".into(),
            expires_tick: 9,
        },
    )
    .expect("fixture lease")
}
fn executed(exit_code: i32) -> Record {
    step(
        &leased(),
        4,
        Operation::Receipt {
            token: "lease-1".into(),
            receipt: Receipt {
                attempt: 1,
                executor: "operator".into(),
                command: "fixture command; never executed".into(),
                exit_code,
                log: proof(),
                result: "fixture outcome".into(),
                tick: 4,
            },
        },
    )
    .expect("fixture receipt")
}

#[test]
fn stable_ids_and_profile_travel() {
    let a = ready();
    let b = ready();
    assert_eq!(
        a.action.as_ref().expect("action").id,
        b.action.as_ref().expect("action").id
    );
    assert_eq!(
        leased().action.expect("action").profile,
        Profile::PrototypeTooling
    );
}
#[test]
fn original_rejection_is_preserved() {
    assert_eq!(ready().artifact.original_verdict, "rejected");
}
#[test]
fn producer_and_co_writer_review_refused() {
    let r = Record::new(artifact(), policy()).expect("fixture");
    for who in ["qwen", "co-writer", "QWEN"] {
        assert!(
            step(
                &r,
                1,
                Operation::Review {
                    review: review(&r, who, Disposition::FollowUp)
                }
            )
            .is_err()
        );
    }
}
#[test]
fn stale_binding_refused() {
    let r = Record::new(artifact(), policy()).expect("fixture");
    let mut v = review(&r, "reviewer", Disposition::FollowUp);
    v.artifact_sha256 = "b".repeat(64);
    assert!(step(&r, 1, Operation::Review { review: v }).is_err());
}
#[test]
fn unreviewed_and_rejected_cannot_plan() {
    let r = Record::new(artifact(), policy()).expect("fixture");
    let plan = || Operation::Plan {
        task: "task".into(),
        acceptance: "criterion".into(),
        destination: "inbox".into(),
    };
    assert!(step(&r, 1, plan()).is_err());
    let rejected = step(
        &r,
        1,
        Operation::Review {
            review: review(&r, "reviewer", Disposition::Rejected),
        },
    )
    .expect("reject");
    assert!(step(&rejected, 2, plan()).is_err());
}
#[test]
fn knowledge_deferred_superseded_do_not_dispatch() {
    for disposition in [
        Disposition::Knowledge,
        Disposition::Deferred,
        Disposition::Superseded,
    ] {
        let r = Record::new(artifact(), policy()).expect("fixture");
        let r = step(
            &r,
            1,
            Operation::Review {
                review: review(&r, "reviewer", disposition),
            },
        )
        .expect("review");
        assert!(
            StewardIntake {
                runtime_root: std::path::PathBuf::from("fixture-root")
            }
            .project(&r)
            .is_err()
        );
    }
}
#[test]
fn concurrent_lease_and_wrong_receipt_refused() {
    let r = leased();
    assert!(
        step(
            &r,
            4,
            Operation::Lease {
                seat: "other".into(),
                token: "other".into(),
                expires_tick: 8
            }
        )
        .is_err()
    );
    let mut receipt = executed(0).action.expect("action").receipts[0].clone();
    receipt.executor = "other".into();
    assert!(
        step(
            &r,
            4,
            Operation::Receipt {
                token: "lease-1".into(),
                receipt
            }
        )
        .is_err()
    );
}
#[test]
fn expired_lease_reassigned_with_budget() {
    let r = step(
        &leased(),
        9,
        Operation::Lease {
            seat: "other".into(),
            token: "lease-2".into(),
            expires_tick: 12,
        },
    )
    .expect("reassignment");
    assert_eq!(r.action.as_ref().expect("action").attempt, 2);
    assert!(
        step(
            &r,
            12,
            Operation::Lease {
                seat: "other".into(),
                token: "lease-3".into(),
                expires_tick: 14
            }
        )
        .is_err()
    );
}
#[test]
fn failed_receipt_defers_then_retries() {
    let r = executed(1);
    assert_eq!(
        r.action.as_ref().expect("action").state,
        ActionState::Failed
    );
    let r = step(
        &r,
        5,
        Operation::Defer {
            reason: "tool failed; needs repair".into(),
        },
    )
    .expect("defer");
    let r = step(
        &r,
        6,
        Operation::Retry {
            reason: "repair receipt reviewed".into(),
        },
    )
    .expect("retry");
    assert_eq!(r.action.as_ref().expect("action").receipts.len(), 1);
    assert_eq!(r.action.expect("action").state, ActionState::Proposed);
}
#[test]
fn closure_requires_receipt_bound_independent_review() {
    let r = executed(0);
    let mut v = review(&r, "independent", Disposition::Knowledge);
    assert!(step(&r, 5, Operation::Close { review: v.clone() }).is_err());
    v.action_sha256 = Some(digest(r.action.as_ref().expect("action")).expect("digest"));
    let mut self_review = v.clone();
    self_review.reviewer = "operator".into();
    assert!(
        step(
            &r,
            5,
            Operation::Close {
                review: self_review
            }
        )
        .is_err()
    );
    assert_eq!(
        step(&r, 5, Operation::Close { review: v })
            .expect("close")
            .action
            .expect("action")
            .state,
        ActionState::Closed
    );
}
#[test]
fn zero_exit_can_be_challenged_semantically() {
    let r = executed(0);
    let mut v = review(&r, "independent", Disposition::Rejected);
    v.action_sha256 = Some(digest(r.action.as_ref().expect("action")).expect("digest"));
    let r = step(&r, 5, Operation::Challenge { review: v }).expect("challenge");
    assert_eq!(
        r.action.as_ref().expect("action").state,
        ActionState::Failed
    );
    assert_eq!(r.action.expect("action").assessments.len(), 1);
}
#[test]
fn failed_execution_cannot_close() {
    let r = executed(1);
    let mut v = review(&r, "independent", Disposition::Knowledge);
    v.action_sha256 = Some(digest(r.action.as_ref().expect("action")).expect("digest"));
    assert!(step(&r, 5, Operation::Close { review: v }).is_err());
}
#[test]
fn stale_version_and_backwards_tick_refused() {
    let r = ready();
    assert!(
        reduce(
            &r,
            &Event {
                expected_version: 0,
                tick: 3,
                operation: Operation::Defer {
                    reason: "blocked".into()
                }
            },
            &policy()
        )
        .is_err()
    );
    assert!(
        step(
            &r,
            1,
            Operation::Defer {
                reason: "blocked".into()
            }
        )
        .is_err()
    );
}
#[test]
fn sql_projection_collision_capacity_and_reopen() {
    let dir = tempfile::tempdir().expect("sandbox");
    let path = dir.path().join("catalog.db");
    let mut store = SqliteCatalog::open(&path, 1).expect("open");
    let r = ready();
    store.compare_and_set(None, &r).expect("insert");
    assert!(store.compare_and_set(None, &r).is_err());
    let mut second = artifact();
    second.id = "different".into();
    assert!(
        store
            .compare_and_set(None, &Record::new(second, policy()).expect("fixture"))
            .is_err()
    );
    drop(store);
    let store = SqliteCatalog::open(&path, 1).expect("reopen");
    assert_eq!(store.get(&r.artifact.id).expect("get"), Some(r));
}
#[test]
fn malformed_json_and_evidence_refused() {
    assert!(
        serde_json::from_str::<Event>(
            r#"{"expected_version":0,"tick":1,"operation":{"type":"delete_cache"}}"#
        )
        .is_err()
    );
    let mut a = artifact();
    a.evidence[0].sha256 = "short".into();
    assert!(Record::new(a, policy()).is_err());
}

#[test]
fn catalog_search_is_bounded_and_rebuildable() {
    let dir = tempfile::tempdir().expect("sandbox");
    let mut store = SqliteCatalog::open(&dir.path().join("search.db"), 4).expect("open");
    store.compare_and_set(None, &ready()).expect("insert");
    assert_eq!(store.search("LEXICAL").expect("query").len(), 1);
    assert!(store.search("unrelated").expect("query").is_empty());
    assert!(store.search("bad\nquery").is_err());
}
#[test]
fn expired_exhausted_lease_can_be_deferred() {
    let r = step(
        &leased(),
        9,
        Operation::Lease {
            seat: "other".into(),
            token: "lease-2".into(),
            expires_tick: 12,
        },
    )
    .expect("second lease");
    assert!(
        step(
            &r,
            11,
            Operation::Defer {
                reason: "active lease".into()
            }
        )
        .is_err()
    );
    let r = step(
        &r,
        12,
        Operation::Defer {
            reason: "seat failed to respond; budget exhausted".into(),
        },
    )
    .expect("defer expired");
    assert!(r.action.as_ref().expect("action").lease.is_none());
    assert!(
        step(
            &r,
            13,
            Operation::Retry {
                reason: "try again".into()
            }
        )
        .is_err()
    );
}
#[test]
fn stage_contract_uses_injected_policy() {
    let r = Record::new(artifact(), policy()).expect("fixture");
    let event = Event {
        expected_version: 0,
        tick: 1,
        operation: Operation::Review {
            review: review(&r, "reviewer", Disposition::Knowledge),
        },
    };
    let stage = DispositionStage { policy: policy() };
    assert_eq!(
        stage.apply(&r, &event).expect("stage"),
        reduce(&r, &event, &policy()).expect("reducer")
    );
}

#[test]
fn stale_attempt_cannot_reuse_token_or_complete_reassignment() {
    let r = leased();
    assert!(
        step(
            &r,
            9,
            Operation::Lease {
                seat: "operator".into(),
                token: "lease-1".into(),
                expires_tick: 12
            }
        )
        .is_err()
    );
    let next = step(
        &r,
        9,
        Operation::Lease {
            seat: "operator".into(),
            token: "lease-2".into(),
            expires_tick: 12,
        },
    )
    .expect("fresh lease");
    let mut receipt = executed(0).action.expect("action").receipts[0].clone();
    receipt.tick = 10;
    assert!(
        step(
            &next,
            10,
            Operation::Receipt {
                token: "lease-1".into(),
                receipt: receipt.clone()
            }
        )
        .is_err()
    );
    assert!(
        step(
            &next,
            10,
            Operation::Receipt {
                token: "lease-2".into(),
                receipt: receipt.clone()
            }
        )
        .is_err()
    );
    receipt.attempt = 2;
    assert!(
        step(
            &next,
            10,
            Operation::Receipt {
                token: "lease-2".into(),
                receipt
            }
        )
        .is_ok()
    );
}
#[test]
fn replay_validation_refuses_tampered_projection() {
    let mut r = ready();
    r.action.as_mut().expect("action").task = "forged task".into();
    assert!(r.validate().is_err());
    let mut r = executed(0);
    r.action.as_mut().expect("action").state = ActionState::Proposed;
    assert!(r.validate().is_err());
    let mut r = ready();
    r.review.as_mut().expect("review").artifact_sha256 = "b".repeat(64);
    assert!(r.validate().is_err());
    let mut r = ready();
    r.version = 99;
    assert!(r.validate().is_err());
    let r = ready();
    let weaker = Policy {
        max_attempts: 3,
        max_lease_ticks: 6,
    };
    assert!(
        reduce(
            &r,
            &Event {
                expected_version: r.version,
                tick: 3,
                operation: Operation::Lease {
                    seat: "operator".into(),
                    token: "new".into(),
                    expires_tick: 9
                }
            },
            &weaker
        )
        .is_err()
    );
}
#[test]
fn reopening_below_retained_count_fails_explicitly() {
    let dir = tempfile::tempdir().expect("sandbox");
    let path = dir.path().join("capacity.db");
    let mut store = SqliteCatalog::open(&path, 2).expect("open");
    store.compare_and_set(None, &ready()).expect("first");
    let mut a = artifact();
    a.id = "second".into();
    store
        .compare_and_set(None, &Record::new(a, policy()).expect("second"))
        .expect("insert");
    drop(store);
    assert!(SqliteCatalog::open(&path, 1).is_err());
    assert_eq!(
        SqliteCatalog::open(&path, 2)
            .expect("reopen")
            .list()
            .expect("all")
            .len(),
        2
    );
}
#[test]
fn database_row_identity_version_and_state_are_validated() {
    let dir = tempfile::tempdir().expect("sandbox");
    let path = dir.path().join("tamper.db");
    let mut store = SqliteCatalog::open(&path, 4).expect("open");
    let r = ready();
    store.compare_and_set(None, &r).expect("insert");
    drop(store);
    let raw = rusqlite::Connection::open(&path).expect("fixture connection");
    raw.execute("UPDATE catalog SET version=99", [])
        .expect("fixture mutation");
    assert!(
        SqliteCatalog::open(&path, 4)
            .expect("open")
            .get(&r.artifact.id)
            .is_err()
    );
    raw.execute("UPDATE catalog SET version=?1", [r.version as i64])
        .expect("restore fixture version");
    let mut forged = r.clone();
    forged.action.as_mut().expect("action").state = ActionState::Closed;
    raw.execute(
        "UPDATE catalog SET body=?1",
        [serde_json::to_string(&forged).expect("fixture JSON")],
    )
    .expect("mutate fixture");
    assert!(SqliteCatalog::open(&path, 4).expect("open").list().is_err());
}

#[test]
fn catalog_updates_extend_history_and_preserve_closed_records() {
    let dir = tempfile::tempdir().expect("sandbox");
    let path = dir.path().join("history.db");
    let mut store = SqliteCatalog::open(&path, 4).expect("open");
    let r = executed(0);
    let mut v = review(&r, "independent", Disposition::Knowledge);
    v.action_sha256 = Some(digest(r.action.as_ref().expect("action")).expect("digest"));
    let closed = step(&r, 5, Operation::Close { review: v }).expect("closed");
    store.compare_and_set(None, &closed).expect("store closed");
    let original = rusqlite::Connection::open(&path)
        .expect("read fixture")
        .query_row("SELECT body FROM catalog", [], |r| r.get::<_, String>(0))
        .expect("original bytes");
    let mut alternate = ready();
    for tick in [3, 5] {
        alternate = step(
            &alternate,
            tick,
            Operation::Defer {
                reason: "alternate branch".into(),
            },
        )
        .expect("defer");
        alternate = step(
            &alternate,
            tick + 1,
            Operation::Retry {
                reason: "alternate branch".into(),
            },
        )
        .expect("retry");
    }
    assert!(alternate.version > closed.version);
    assert!(alternate.validate().is_ok());
    assert!(
        store
            .compare_and_set(Some(closed.version), &alternate)
            .is_err()
    );
    assert_eq!(
        store.get(&closed.artifact.id).expect("get"),
        Some(closed.clone())
    );
    let after = rusqlite::Connection::open(&path)
        .expect("read fixture")
        .query_row("SELECT body FROM catalog", [], |r| r.get::<_, String>(0))
        .expect("retained bytes");
    assert_eq!(original, after);
    let mut a = artifact();
    a.id = "ongoing".into();
    let initial = Record::new(a, policy()).expect("initial");
    store
        .compare_and_set(None, &initial)
        .expect("insert ongoing");
    let next = step(
        &initial,
        1,
        Operation::Review {
            review: review(&initial, "reviewer", Disposition::Knowledge),
        },
    )
    .expect("legal extension");
    store
        .compare_and_set(Some(initial.version), &next)
        .expect("history extension accepted");
}

#[test]
fn catalog_rejects_oversized_native_rows_without_projection_copy() {
    let sandbox = tempfile::tempdir().expect("sandbox");
    let path = sandbox.path().join("oversized.db");
    drop(SqliteCatalog::open(&path, 4).expect("initialize"));
    let raw = rusqlite::Connection::open(&path).expect("fixture");
    raw.execute(
        "INSERT INTO catalog VALUES ('huge',0,?1)",
        ["x".repeat(2_101_249)],
    )
    .expect("oversized fixture");
    let store = SqliteCatalog::open(&path, 4).expect("open within capacity");
    assert!(store.get("huge").is_err());
    assert!(store.list().is_err());
    assert!(store.get(&"a".repeat(257)).is_err());
    assert!(store.search(&"a".repeat(257)).is_err());
}
#[test]
fn catalog_update_rechecks_capacity_inside_write_transaction() {
    let sandbox = tempfile::tempdir().expect("sandbox");
    let path = sandbox.path().join("capacity-race.db");
    let mut narrow = SqliteCatalog::open(&path, 1).expect("narrow");
    let initial = ready();
    narrow.compare_and_set(None, &initial).expect("first");
    let mut wide = SqliteCatalog::open(&path, 2).expect("wide");
    let mut a = artifact();
    a.id = "other".into();
    wide.compare_and_set(None, &Record::new(a, policy()).expect("other"))
        .expect("separate writer");
    let updated = step(
        &initial,
        3,
        Operation::Defer {
            reason: "bounded defer".into(),
        },
    )
    .expect("update");
    assert!(
        narrow
            .compare_and_set(Some(initial.version), &updated)
            .is_err()
    );
    assert_eq!(
        wide.get(&initial.artifact.id).expect("retained"),
        Some(initial)
    );
}
