#![deny(unsafe_code)]
use cap_std::fs::{Dir, OpenOptions};
use output_lifecycle_prototype::catalog::{Catalog, SqliteCatalog};
use output_lifecycle_prototype::{
    DispositionStage, Evidence, IntakeAdapter, JsonObservation, ModelObservation, Policy, Record,
    Result, Scenario, Stage, StewardIntake, digest,
};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::{
    fs,
    io::{Read, Write},
    path::{Component, Path, PathBuf},
};

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct HostConfig {
    intake_root: PathBuf,
    output_root: PathBuf,
    allowed_reads: Vec<PathBuf>,
    policy: Policy,
    catalog_capacity: usize,
}

fn bounded_read(path: &Path, cap: u64) -> Result<Vec<u8>> {
    let parent = path.parent().ok_or("file requires parent directory")?;
    let dir =
        Dir::open_ambient_dir(parent, cap_std::ambient_authority()).map_err(|e| e.to_string())?;
    let name = path.file_name().ok_or("file requires name")?;
    let file = dir.open(name).map_err(|e| e.to_string())?;
    let mut bytes = vec![];
    file.take(cap + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() as u64 > cap {
        return Err("input exceeds byte budget".into());
    }
    Ok(bytes)
}
fn json_read<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T> {
    safe_path(path)?;
    serde_json::from_slice(&bounded_read(path, 2_097_152)?).map_err(|e| e.to_string())
}
fn safe_path(path: &Path) -> Result<()> {
    if !path.is_absolute()
        || path
            .components()
            .any(|c| matches!(c, Component::ParentDir | Component::CurDir))
    {
        return Err("paths must be absolute without dot traversal".into());
    }
    for ancestor in path.ancestors() {
        match fs::symlink_metadata(ancestor) {
            Ok(meta) => {
                if meta.file_type().is_symlink() {
                    return Err("symlink paths refused".into());
                }
                #[cfg(windows)]
                {
                    use std::os::windows::fs::MetadataExt;
                    if meta.file_attributes() & 0x400 != 0 {
                        return Err("reparse paths refused".into());
                    }
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(e.to_string()),
        }
    }
    Ok(())
}
fn output_path(config: &HostConfig, path: &Path) -> Result<()> {
    safe_path(&config.output_root)?;
    safe_path(path)?;
    if !path.starts_with(&config.output_root) || path == config.output_root {
        return Err("output outside injected root".into());
    }
    Ok(())
}
fn verify(config: &HostConfig, evidence: &Evidence) -> Result<()> {
    output_lifecycle_prototype::evidence_valid(evidence)?;
    let path = Path::new(&evidence.path);
    safe_path(path)?;
    if !config.allowed_reads.iter().any(|p| p == path) {
        return Err("evidence outside explicit read allowlist".into());
    }
    let bytes = bounded_read(path, 8_388_608)?;
    if !format!("{:x}", Sha256::digest(bytes)).eq_ignore_ascii_case(&evidence.sha256) {
        return Err("stale evidence hash".into());
    }
    Ok(())
}
fn verify_record(config: &HostConfig, record: &Record) -> Result<()> {
    record.validate()?;
    if record.policy != config.policy {
        return Err("stored policy differs from host policy".into());
    }
    if digest(&record.artifact)? != record.artifact_sha256 {
        return Err("artifact binding mismatch".into());
    }
    for evidence in record.evidence() {
        verify(config, evidence)?;
    }
    Ok(())
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PublishPoint {
    Prepared,
    Linked,
}

fn cap_read(dir: &Dir, path: &Path) -> Result<Vec<u8>> {
    let file = dir.open(path).map_err(|e| e.to_string())?;
    let mut bytes = vec![];
    file.take(2_097_153)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() > 2_097_152 {
        return Err("output exceeds byte budget".into());
    }
    Ok(bytes)
}
fn prepared_name(path: &Path, bytes: &[u8]) -> Result<PathBuf> {
    let name = path
        .file_name()
        .and_then(|v| v.to_str())
        .ok_or("output requires UTF-8 filename")?;
    if name.starts_with(".prepared-") {
        return Err("reserved publication name".into());
    }
    let key = serde_json::to_vec(&(name, format!("{:x}", Sha256::digest(bytes))))
        .map_err(|e| e.to_string())?;
    Ok(PathBuf::from(format!(
        ".prepared-{:x}",
        Sha256::digest(key)
    )))
}
fn publish_bytes(
    dir: &Dir,
    relative: &Path,
    bytes: &[u8],
    checkpoint: &dyn Fn(PublishPoint) -> Result<()>,
) -> Result<()> {
    if relative.as_os_str().is_empty()
        || relative
            .components()
            .any(|c| !matches!(c, Component::Normal(_)))
    {
        return Err("publication requires a confined relative file path".into());
    }
    if bytes.len() > 2_097_152 {
        return Err("output exceeds byte budget".into());
    }
    let parent = relative.parent().ok_or("output parent required")?;
    let dir = if parent.as_os_str().is_empty() {
        dir.try_clone()
    } else {
        dir.open_dir(parent)
    }
    .map_err(|e| e.to_string())?;
    let name = Path::new(relative.file_name().ok_or("output filename required")?);
    let stage = prepared_name(name, bytes)?;
    match dir.symlink_metadata(name) {
        Ok(meta) => {
            if !meta.is_file() || meta.file_type().is_symlink() {
                return Err("nonregular output refused".into());
            }
            if cap_read(&dir, name)? == bytes {
                return Ok(());
            }
            return Err("output collision; original preserved".into());
        }
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => return Err(e.to_string()),
    }
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    match dir.open_with(&stage, &options) {
        Ok(mut file) => {
            file.write_all(bytes).map_err(|e| e.to_string())?;
            file.sync_all().map_err(|e| e.to_string())?;
        }
        Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
            let meta = dir.symlink_metadata(&stage).map_err(|e| e.to_string())?;
            if !meta.is_file() || meta.file_type().is_symlink() || cap_read(&dir, &stage)? != bytes
            {
                return Err("incomplete/conflicting prepared publication retained; choose a new output path".into());
            }
        }
        Err(e) => return Err(e.to_string()),
    }
    checkpoint(PublishPoint::Prepared)?;
    // Hard-link publication creates the final name without overwriting an existing name.
    match dir.hard_link(&stage, &dir, name) {
        Ok(()) => {}
        Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {
            if cap_read(&dir, name)? != bytes {
                return Err("concurrent output collision; original preserved".into());
            }
        }
        Err(e) => return Err(e.to_string()),
    }
    checkpoint(PublishPoint::Linked)?;
    // Keep the prepared link as a recovery receipt; housekeeping has no deletion authority.
    if cap_read(&dir, name)? != bytes {
        return Err("published bytes changed; safe hold".into());
    }
    Ok(())
}
fn publish(
    config: &HostConfig,
    dir: &Dir,
    path: &Path,
    value: &impl serde::Serialize,
) -> Result<()> {
    output_path(config, path)?;
    let bytes = serde_json::to_vec_pretty(value).map_err(|e| e.to_string())?;
    let relative = path
        .strip_prefix(&config.output_root)
        .map_err(|e| e.to_string())?;
    publish_bytes(dir, relative, &bytes, &|_| Ok(()))
}
fn run(args: &[String]) -> Result<()> {
    if args.len() != 5 {
        return Err("Usage: output-lifecycle-prototype <replay|catalog|export|observe> <host.json> <input-or-id> <db-or-result.json> <output.json>".into());
    }
    let config: HostConfig = json_read(Path::new(&args[1]))?;
    safe_path(&config.output_root)?;
    // Bootstrap acquires explicit authority once; publication uses this injected handle.
    let output_dir = Dir::open_ambient_dir(&config.output_root, cap_std::ambient_authority())
        .map_err(|e| e.to_string())?;
    let input = &args[2];
    let db = Path::new(&args[3]);
    let output = Path::new(&args[4]);
    output_path(&config, output)?;
    match args[0].as_str() {
        "observe" => {
            let evidence: Evidence = json_read(Path::new(input))?;
            verify(&config, &evidence)?;
            let adapter = JsonObservation {
                payload: json_read(Path::new(&evidence.path))?,
            };
            let raw = adapter.read()?;
            publish(
                &config,
                &output_dir,
                output,
                &serde_json::json!({"schema_version":1,"kind":"model_observation",
                "source":evidence,"accepted":false,"product_verified":false,"observation":raw}),
            )
        }
        "replay" => {
            output_path(&config, db)?;
            let scenario: Scenario = json_read(Path::new(input))?;
            if scenario.events.len() > 64 {
                return Err("event budget exceeded".into());
            }
            let mut record = Record::new(scenario.artifact, config.policy.clone())?;
            verify_record(&config, &record)?;
            let stage = DispositionStage {
                policy: config.policy.clone(),
            };
            for event in scenario.events {
                record = stage.apply(&record, &event)?;
                verify_record(&config, &record)?;
            }
            // Detect output collision before committing a catalog projection.
            if output.exists() {
                let desired = serde_json::to_vec_pretty(&record).map_err(|e| e.to_string())?;
                if bounded_read(output, 2_097_152)? != desired {
                    return Err("output collision before catalog commit".into());
                }
            }
            let mut catalog = SqliteCatalog::open(db, config.catalog_capacity)?;
            match catalog.get(&record.artifact.id)? {
                Some(stored) if stored == record => {}
                Some(_) => {
                    return Err(
                        "catalog already has a different replay; new revision required".into(),
                    );
                }
                None => catalog.compare_and_set(None, &record)?,
            }
            publish(&config, &output_dir, output, &record)
        }
        "catalog" => {
            output_path(&config, db)?;
            let catalog = SqliteCatalog::open(db, config.catalog_capacity)?;
            let records = if input == "-" {
                catalog.list()?
            } else {
                catalog.search(input)?
            };
            for record in &records {
                verify_record(&config, record)?;
            }
            publish(
                &config,
                &output_dir,
                output,
                &serde_json::json!({"schema_version":1,"product_verified":false,"records":records}),
            )
        }
        "export" => {
            output_path(&config, db)?;
            let catalog = SqliteCatalog::open(db, config.catalog_capacity)?;
            let record = catalog.get(input)?.ok_or("unknown artifact ID")?;
            verify_record(&config, &record)?;
            publish(
                &config,
                &output_dir,
                output,
                &StewardIntake {
                    runtime_root: config.intake_root.clone(),
                }
                .project(&record)?,
            )
        }
        _ => Err("unknown option; no action performed".into()),
    }
}
fn main() {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if let Err(error) = run(&args) {
        eprintln!("{error}");
        std::process::exit(1);
    }
}

#[cfg(test)]
mod publication_tests {
    use super::*;
    fn dir(root: &Path) -> Dir {
        Dir::open_ambient_dir(root, cap_std::ambient_authority()).expect("test sandbox")
    }
    #[test]
    fn interruption_before_final_name_is_recoverable() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let root = dir(sandbox.path());
        let target = Path::new("record.json");
        assert!(
            publish_bytes(&root, target, b"complete bytes", &|point| if point
                == PublishPoint::Prepared
            {
                Err("injected interruption".into())
            } else {
                Ok(())
            })
            .is_err()
        );
        assert!(!sandbox.path().join(target).exists());
        assert_eq!(
            cap_read(
                &root,
                &prepared_name(target, b"complete bytes").expect("stage")
            )
            .expect("prepared"),
            b"complete bytes"
        );
        publish_bytes(&root, target, b"complete bytes", &|_| Ok(())).expect("resume");
        assert_eq!(
            cap_read(&root, target).expect("complete"),
            b"complete bytes"
        );
    }
    #[test]
    fn interruption_after_link_is_idempotent() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let root = dir(sandbox.path());
        let target = Path::new("linked.json");
        assert!(
            publish_bytes(
                &root,
                target,
                b"complete",
                &|point| if point == PublishPoint::Linked {
                    Err("injected interruption".into())
                } else {
                    Ok(())
                }
            )
            .is_err()
        );
        publish_bytes(&root, target, b"complete", &|_| Ok(())).expect("repeat");
        assert_eq!(cap_read(&root, target).expect("retained"), b"complete");
    }
    #[test]
    fn partial_preparation_and_final_collisions_preserve_history() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let root = dir(sandbox.path());
        let target = Path::new("partial.json");
        let stage = prepared_name(target, b"complete").expect("stage");
        root.write(&stage, b"partial").expect("fault fixture");
        assert!(publish_bytes(&root, target, b"complete", &|_| Ok(())).is_err());
        assert_eq!(cap_read(&root, &stage).expect("preserved"), b"partial");
        assert!(!sandbox.path().join(target).exists());
        root.write("collision.json", b"original").expect("fixture");
        assert!(
            publish_bytes(&root, Path::new("collision.json"), b"replacement", &|_| Ok(
                ()
            ))
            .is_err()
        );
        assert_eq!(
            cap_read(&root, Path::new("collision.json")).expect("original"),
            b"original"
        );
    }
    #[test]
    fn relative_escape_and_reserved_stage_names_are_refused() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let root = dir(sandbox.path());
        for target in ["../escape.json", ".prepared-conflict", "./alias.json"] {
            assert!(publish_bytes(&root, Path::new(target), b"x", &|_| Ok(())).is_err());
        }
    }
    #[cfg(unix)]
    #[test]
    fn symlink_escape_is_refused_by_directory_capability() {
        let sandbox = tempfile::tempdir().expect("sandbox");
        let outside = tempfile::tempdir().expect("outside");
        std::os::unix::fs::symlink(outside.path(), sandbox.path().join("escape"))
            .expect("fixture link");
        let root = dir(sandbox.path());
        assert!(publish_bytes(&root, Path::new("escape/out.json"), b"x", &|_| Ok(())).is_err());
        assert!(!outside.path().join("out.json").exists());
    }
}
