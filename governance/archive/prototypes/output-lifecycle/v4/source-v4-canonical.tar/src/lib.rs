#![deny(unsafe_code)]

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

pub mod catalog;
pub type Result<T> = std::result::Result<T, String>;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Evidence {
    pub path: String,
    pub sha256: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Artifact {
    pub schema_version: u32,
    pub id: String,
    pub kind: String,
    pub producer: String,
    pub contributors: Vec<String>,
    pub source_revision: String,
    pub original_verdict: String,
    pub profile: Profile,
    pub evidence: Vec<Evidence>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Profile {
    PrototypeTooling,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Disposition {
    PendingReview,
    Rejected,
    Deferred,
    FollowUp,
    Knowledge,
    Superseded,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Review {
    pub reviewer: String,
    pub artifact_sha256: String,
    pub action_sha256: Option<String>,
    pub disposition: Disposition,
    pub scope: String,
    pub note: String,
    pub receipt: Evidence,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ActionState {
    Proposed,
    Leased,
    Executed,
    Failed,
    Deferred,
    Closed,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Lease {
    pub seat: String,
    pub token: String,
    pub expires_tick: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Receipt {
    pub attempt: u32,
    pub executor: String,
    pub command: String,
    pub exit_code: i32,
    pub log: Evidence,
    pub result: String,
    pub tick: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Action {
    pub lease_tokens: Vec<String>,
    pub id: String,
    pub task: String,
    pub acceptance: String,
    pub destination: String,
    pub profile: Profile,
    pub state: ActionState,
    pub attempt: u32,
    pub lease: Option<Lease>,
    pub receipts: Vec<Receipt>,
    pub blocker: Option<String>,
    pub closure: Option<Review>,
    pub assessments: Vec<Review>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Record {
    pub schema_version: u32,
    pub policy: Policy,
    pub history: Vec<Event>,
    pub artifact: Artifact,
    pub artifact_sha256: String,
    pub version: u64,
    pub disposition: Disposition,
    pub review: Option<Review>,
    pub action: Option<Action>,
    pub explanation: Option<String>,
    pub last_tick: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum Operation {
    Review {
        review: Review,
    },
    Plan {
        task: String,
        acceptance: String,
        destination: String,
    },
    Lease {
        seat: String,
        token: String,
        expires_tick: u64,
    },
    Receipt {
        token: String,
        receipt: Receipt,
    },
    Defer {
        reason: String,
    },
    Retry {
        reason: String,
    },
    Close {
        review: Review,
    },
    Challenge {
        review: Review,
    },
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Event {
    pub expected_version: u64,
    pub tick: u64,
    pub operation: Operation,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Scenario {
    pub artifact: Artifact,
    pub events: Vec<Event>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Policy {
    pub max_attempts: u32,
    pub max_lease_ticks: u64,
}

fn bounded(text: &str, max: usize) -> Result<()> {
    if text.trim().is_empty() || text.len() > max || text.chars().any(|c| c.is_control()) {
        return Err("empty, oversized or control-containing field".into());
    }
    Ok(())
}

fn seat(text: &str) -> Result<()> {
    bounded(text, 80)?;
    if !text
        .bytes()
        .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-')
    {
        return Err("seat IDs must be canonical lowercase ASCII identifiers".into());
    }
    Ok(())
}

pub fn evidence_valid(e: &Evidence) -> Result<()> {
    bounded(&e.path, 1024)?;
    if e.sha256.len() != 64 || !e.sha256.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("evidence SHA must be full SHA256".into());
    }
    Ok(())
}

pub fn digest<T: Serialize>(value: &T) -> Result<String> {
    let bytes = serde_json::to_vec(value).map_err(|e| e.to_string())?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

impl Record {
    pub fn new(artifact: Artifact, policy: Policy) -> Result<Self> {
        if policy.max_attempts == 0 || policy.max_attempts > 3 || policy.max_lease_ticks == 0 {
            return Err("invalid bounded policy".into());
        }
        if artifact.schema_version != 1
            || artifact.evidence.is_empty()
            || artifact.evidence.len() > 8
        {
            return Err("schema1 requires 1..8 evidence files".into());
        }
        bounded(&artifact.id, 160)?;
        bounded(&artifact.kind, 80)?;
        bounded(&artifact.source_revision, 200)?;
        bounded(&artifact.original_verdict, 120)?;
        seat(&artifact.producer)?;
        for contributor in &artifact.contributors {
            seat(contributor)?;
        }
        for evidence in &artifact.evidence {
            evidence_valid(evidence)?;
        }
        let artifact_sha256 = digest(&artifact)?;
        Ok(Self {
            schema_version: 2,
            policy,
            history: vec![],
            artifact,
            artifact_sha256,
            version: 0,
            disposition: Disposition::PendingReview,
            review: None,
            action: None,
            explanation: None,
            last_tick: 0,
        })
    }

    pub fn validate(&self) -> Result<()> {
        if self.history.len() > 64 {
            return Err("history budget exceeded".into());
        }
        let mut expected = Self::new(self.artifact.clone(), self.policy.clone())?;
        for event in &self.history {
            expected = reduce_unchecked(&expected, event, &self.policy)?;
        }
        if expected != *self {
            return Err("projection differs from legal event replay".into());
        }
        Ok(())
    }
    pub fn evidence(&self) -> Vec<&Evidence> {
        let mut refs: Vec<_> = self.artifact.evidence.iter().collect();
        if let Some(review) = &self.review {
            refs.push(&review.receipt);
        }
        if let Some(action) = &self.action {
            refs.extend(action.receipts.iter().map(|r| &r.log));
            if let Some(review) = &action.closure {
                refs.push(&review.receipt);
            }
            refs.extend(action.assessments.iter().map(|r| &r.receipt));
        }
        refs
    }
}

fn validate_review(record: &Record, review: &Review) -> Result<()> {
    seat(&review.reviewer)?;
    if review.reviewer == record.artifact.producer
        || record.artifact.contributors.contains(&review.reviewer)
    {
        return Err("producer or co-writer cannot independently review".into());
    }
    if review.artifact_sha256 != record.artifact_sha256 {
        return Err("review is bound to another artifact".into());
    }
    bounded(&review.scope, 1200)?;
    bounded(&review.note, 4000)?;
    evidence_valid(&review.receipt)
}

/// Pure domain transition; callers inject policy, ordered version and logical tick.
/// It records evidence claims; trusted host adapters must validate evidence/identity.
pub fn reduce(current: &Record, event: &Event, policy: &Policy) -> Result<Record> {
    current.validate()?;
    reduce_unchecked(current, event, policy)
}
fn reduce_unchecked(current: &Record, event: &Event, policy: &Policy) -> Result<Record> {
    if policy != &current.policy || current.history.len() >= 64 {
        return Err("policy changed or history budget exceeded".into());
    }

    if policy.max_attempts == 0 || policy.max_attempts > 3 || policy.max_lease_ticks == 0 {
        return Err("invalid bounded policy".into());
    }
    if event.expected_version != current.version || event.tick < current.last_tick {
        return Err("stale version or backwards tick".into());
    }
    let mut next = current.clone();
    match &event.operation {
        Operation::Review { review } => {
            if current.disposition != Disposition::PendingReview {
                return Err("review already recorded".into());
            }
            validate_review(current, review)?;
            if review.action_sha256.is_some() {
                return Err("initial review cannot reference an action".into());
            }
            if review.disposition == Disposition::PendingReview {
                return Err("review needs a concrete disposition".into());
            }
            next.disposition = review.disposition.clone();
            next.review = Some(review.clone());
        }
        Operation::Plan {
            task,
            acceptance,
            destination,
        } => {
            if current.disposition != Disposition::FollowUp || current.action.is_some() {
                return Err("only reviewed follow-up may receive one action".into());
            }
            bounded(task, 2000)?;
            bounded(acceptance, 2000)?;
            bounded(destination, 160)?;
            next.action = Some(Action {
                lease_tokens: vec![],
                id: digest(&(
                    current.artifact_sha256.as_str(),
                    task,
                    acceptance,
                    destination,
                ))?,
                task: task.clone(),
                acceptance: acceptance.clone(),
                destination: destination.clone(),
                profile: current.artifact.profile.clone(),
                state: ActionState::Proposed,
                attempt: 0,
                lease: None,
                receipts: vec![],
                blocker: None,
                closure: None,
                assessments: vec![],
            });
        }
        Operation::Lease {
            seat: holder,
            token,
            expires_tick,
        } => {
            seat(holder)?;
            bounded(token, 160)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            let expired = action
                .lease
                .as_ref()
                .is_some_and(|l| l.expires_tick <= event.tick);
            if action.state != ActionState::Proposed
                && !(action.state == ActionState::Leased && expired)
            {
                return Err("action is not available for lease".into());
            }
            if *expires_tick <= event.tick || *expires_tick - event.tick > policy.max_lease_ticks {
                return Err("invalid lease expiry".into());
            }
            if action.attempt >= policy.max_attempts {
                return Err("attempt budget exhausted".into());
            }
            if action.lease_tokens.contains(token) {
                return Err("lease token already used".into());
            }
            action.lease_tokens.push(token.clone());
            action.attempt += 1;
            action.lease = Some(Lease {
                seat: holder.clone(),
                token: token.clone(),
                expires_tick: *expires_tick,
            });
            action.state = ActionState::Leased;
        }
        Operation::Receipt { token, receipt } => {
            seat(&receipt.executor)?;
            bounded(&receipt.command, 4000)?;
            bounded(&receipt.result, 4000)?;
            evidence_valid(&receipt.log)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            let lease = action.lease.as_ref().ok_or("missing lease")?;
            if action.state != ActionState::Leased
                || &lease.token != token
                || lease.seat != receipt.executor
                || receipt.attempt != action.attempt
                || lease.expires_tick <= event.tick
                || receipt.tick != event.tick
            {
                return Err("receipt does not match active lease and tick".into());
            }
            action.state = if receipt.exit_code == 0 {
                ActionState::Executed
            } else {
                ActionState::Failed
            };
            action.receipts.push(receipt.clone());
            action.lease = None;
        }
        Operation::Defer { reason } => {
            bounded(reason, 2000)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            if action.state == ActionState::Closed
                || action.state == ActionState::Executed
                || (action.state == ActionState::Leased
                    && action
                        .lease
                        .as_ref()
                        .is_some_and(|l| l.expires_tick > event.tick))
            {
                return Err("cannot defer closed/executed/actively leased action".into());
            }
            action.state = ActionState::Deferred;
            action.lease = None;
            action.blocker = Some(reason.clone());
        }
        Operation::Retry { reason } => {
            bounded(reason, 2000)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            if !matches!(action.state, ActionState::Deferred | ActionState::Failed)
                || action.attempt >= policy.max_attempts
            {
                return Err("retry unavailable or exhausted".into());
            }
            action.state = ActionState::Proposed;
            action.blocker = Some(reason.clone());
        }
        Operation::Challenge { review } => {
            validate_review(current, review)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            if action.state != ActionState::Executed
                || review.disposition != Disposition::Rejected
                || review.action_sha256.as_ref() != Some(&digest(action)?)
                || action
                    .receipts
                    .iter()
                    .any(|r| r.executor == review.reviewer)
            {
                return Err("challenge must independently bind an executed action".into());
            }
            action.state = ActionState::Failed;
            action.blocker = Some(review.note.clone());
            action.assessments.push(review.clone());
        }
        Operation::Close { review } => {
            validate_review(current, review)?;
            let action = next.action.as_mut().ok_or("missing action")?;
            if review.action_sha256.as_ref() != Some(&digest(action)?) {
                return Err("review must bind exact executed action and receipt".into());
            }
            let receipt = action.receipts.last().ok_or("missing execution receipt")?;
            if action.state != ActionState::Executed
                || receipt.exit_code != 0
                || review.reviewer == receipt.executor
                || action
                    .receipts
                    .iter()
                    .any(|r| r.executor == review.reviewer)
                || review.disposition != Disposition::Knowledge
            {
                return Err(
                    "closure needs independent scoped review after successful execution".into(),
                );
            }
            action.state = ActionState::Closed;
            action.closure = Some(review.clone());
        }
    }
    next.version = current.version.checked_add(1).ok_or("version exhausted")?;
    next.last_tick = event.tick;
    next.history.push(event.clone());
    Ok(next)
}

/// Swappable common interface for pipeline stages. Existing scheduler remains external.
pub trait Stage {
    fn apply(&self, record: &Record, event: &Event) -> Result<Record>;
}
pub struct DispositionStage {
    pub policy: Policy,
}
impl Stage for DispositionStage {
    fn apply(&self, record: &Record, event: &Event) -> Result<Record> {
        reduce(record, event, &self.policy)
    }
}

pub trait ModelObservation {
    fn read(&self) -> Result<serde_json::Value>;
}
pub trait IntakeAdapter {
    fn project(&self, record: &Record) -> Result<serde_json::Value>;
}
pub struct JsonObservation {
    pub payload: serde_json::Value,
}
impl ModelObservation for JsonObservation {
    fn read(&self) -> Result<serde_json::Value> {
        Ok(self.payload.clone())
    }
}
pub struct StewardIntake {
    pub runtime_root: std::path::PathBuf,
}
impl IntakeAdapter for StewardIntake {
    fn project(&self, record: &Record) -> Result<serde_json::Value> {
        let action = record.action.as_ref().ok_or("missing action")?;
        if action.state != ActionState::Proposed {
            return Err("only proposed actions can enter candidate intake".into());
        }
        let relative = |e: &Evidence| -> Result<String> {
            std::path::Path::new(&e.path)
                .strip_prefix(&self.runtime_root)
                .map(|p| p.to_string_lossy().replace(char::from(92), "/"))
                .map_err(|_| "intake evidence must reside under the injected runtime root".into())
        };
        let scope: Vec<String> = record
            .artifact
            .evidence
            .iter()
            .map(relative)
            .collect::<Result<_>>()?;
        let source = relative(record.artifact.evidence.first().ok_or("missing evidence")?)?;
        Ok(
            serde_json::json!({"schema_version":1,"id":format!("ACTION-{}",action.id),"source":source,
            "priority":"P2","scope":scope,
            "dependencies":["Independent steward admission, fresh reservations and separate source claim required"],
            "verification":[format!("NOT RUN: {}",action.acceptance)],
            "decision":format!("Advisory prototype candidate for {}: {}. No claim, dispatch, repository edit, approval or product verification.",action.destination,action.task)}),
        )
    }
}

#[cfg(test)]
mod tests;
