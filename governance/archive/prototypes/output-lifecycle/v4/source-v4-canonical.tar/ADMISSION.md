# Dependency admission (isolated tooling only)

No dependency is added to either repository. Current exact resolution is Cargo.lock.
Rust floor1.98; actual compiler1.98.1; no minimum-compiler/Linux claim.
Distances are provisional caller-facing alloc/ambient/abi/safety on0..4 scale.

| Dependency | Vectors | Verdict and conditions |
|---|---|---|
| rusqlite =0.40.2, bundled SQLite | 3/0/2/1 | Admit with conditions for this tooling experiment. Explicit database path/connection; bounded projection; transactions; no extension loading, background tasks or default policy. SQLite C/native provenance stays behind Catalog. Transitive/native audit and platform qualification remain open. |
| serde + serde_json | 2/0/0/0 | Admit with conditions: bounded input before parsing, deny unknown fields on contracts; already used in existing foundation/Rig boundaries. Ordinary tooling allocation only. |
| sha2 | 1/0/0/0 | Admit with conditions: content identity/binding only, never identity authentication or reviewer authority. |
| tempfile (tests only) | 2/0/0/0 | Admit with conditions: explicit test sandbox; never production ambient temp/config. |
| Existing Rig0.43 prototype | see its ADMISSION.md | Reuse retained provider output via ModelObservation; no new Rig runtime/provider/client, model call, feature expansion or product admission. |

No petgraph/vector-store dependency is added: stable IDs and relational projections
cover this bounded case. Existing C99 routing and C100 identity remain responsible
for scheduling/authority. Any production dependency decision requires the full
transitive graph, licenses, native provenance, MSRV/features and independent review.

Initial build exposed unchecked assumptions about SQLite integer conversions;
fixed using checked i64 conversion. Initial export edit lookup/character escape
failed and was repaired; original receipts/logs remain. Bundled SQLite binary link
reported Windows LNK4098 (LIBCMT conflict); qualification must retain its resolution
or limitation. Do not silence the warning or call compilation alone compliance.

Link qualification update: cargo rustc --offline --bin output-lifecycle-prototype -- -C target-feature=+crt-static exited0 with no linker warning. The static-CRT option is a per-build input; no host/global Cargo settings changed. Original LNK4098 log remains retained. Linux and release builds remain NOT VERIFIED.

## cap-std =4.0.3 (default features disabled; v4 experiment)
Provisional caller distance: alloc2 / ambient0 / abi1 / safety1.
Verdict: Admit with conditions for the isolated tooling JSON adapter. Bootstrap
explicitly acquires the owner-declared directory; operations receive that handle.
No library ambient authority, clock, network, worker/task spawn, or provider is used.
Native unsafe/platform code stays in the admitted adapter dependency. Windows and
Linux qualification, independent review, exact transitive/native/license evidence,
and trust of bootstrap/config remain required before official adoption. This does
not grant Aaroneous product admission. SQLite uses its existing VFS independently;
cap-std is not claimed to protect SQLite path acquisition.
Upstream docs: https://github.com/bytecodealliance/cap-std/blob/main/cap-std/README.md
Security review: GHSA-hxf5-99xg-86hw affects cap-std/cap-primitives before3.4.1;
lockfile resolves both4.0.3. This checks that named advisory only, not all advisories.
https://github.com/sunfishcode/cap-std/security/advisories/GHSA-hxf5-99xg-86hw
SQLite limits feature adds bounds and no new external dependency. Worker limit0 and
busy timeout0 prohibit hidden auxiliary execution/retry policy in this adapter.
