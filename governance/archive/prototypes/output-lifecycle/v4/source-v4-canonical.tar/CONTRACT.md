# Output consumption contract v1 (experimental)

Input: Artifact plus ordered Event(expected_version, tick, Operation); Policy is
injected. Output: immutable next Record or explicit error. Side effects are in
adapters. A stage carries PrototypeTooling profile with its action on reassignment.
This single prototype profile is not the complete Cratify profile hierarchy.

Artifact -> PendingReview -> Rejected | Deferred | FollowUp | Knowledge | Superseded.
Only FollowUp can produce one Proposed action. Whole rejected artifacts cannot
plan work; an explicitly extracted useful finding is a separate artifact that
retains original_verdict. Knowledge/deferred/superseded records remain searchable.

Proposed -> Leased -> Executed(exit0) | Failed(nonzero).
Executed -> Closed(exact action-hash independent review) | Failed(independent challenge).
Failed -> Deferred or Proposed(explicit retry).
Deferred -> Proposed(explicit retry/unblocking reason).
Expired Leased -> new Leased(with unchanged action ID/profile, new token and attempt).
Closed is terminal. Max attempts1..3; current host policy2, lease6 logical ticks.
No automatic clock, renewal, retry or inference. Every transition advances version;
stale version/backwards tick/foreign or expired token fails closed. Old receipts and
independent challenges remain retained across attempts. No receipt is a review.

Reviews must bind artifact hash; closure/challenge also binds exact action hash
including execution receipts. Producer/co-writers cannot review; no executor from
any attempt can close or challenge its own action. Seat IDs use lowercase ASCII
identifiers; actual authentication and authority are host obligations.

Evidence consists of1..8 declared paths and full SHA256, checked by the file adapter
before catalog/import/export. Content SHA only proves byte identity. It does not
prove current source freshness, trustworthy reviewer identity, behavior or compliance.
Original source checks stay in existing approved mechanical tools.

Action ID = SHA256(v1 canonical serialization of artifact digest, task, criterion,
destination). Versions and leases are separate. No PR number is required. Future
steward adoption must bind this ID into its existing completion/lease contracts;
this prototype never impersonates an admitted task or writes actual seat outboxes.

ModelObservation only reads advisory JSON. It cannot emit Operation/Review/Lease.
IntakeAdapter translates Proposed action to existing native schema1 candidate.
Unknown operations, arbitrary cleanup, claims, promotion, source writes and model
commands are unavailable. Housekeeping remains a proposal pending approved roots,
retention and tool; the component itself has no deletion or execution capability.

Catalog compare_and_set is transactional and capacity bounded. Scenario artifacts
are retained replay evidence; SQLite is a replaceable projection. Initial scenario
plus events are not cryptographic authentication or a canonical shared event chain.
Host-controlled stack composition and actual scheduler integration are future work;
Stage is the swappable boundary exercised by the reducer and adapters in this build.

## Review-driven v2 correction
Independent read-only review found lease-token reuse, trusted projection state and
silent capacity reduction. All three are repaired in prototype0.1.1. Record schema2
retains explicit injected policy and typed event history. Catalog reads/CAS validate
row ID/version and reconstruct the whole record through the pure reducer before
using its state. Policy cannot silently loosen. This establishes consistency, not
authenticated event provenance; protected host inputs/C100 identity remain required.
Lease tokens are unique across attempts and receipts explicitly bind their attempt.
Capacity reduction below retained count fails explicitly; records are never hidden.
Four additional regression families exercise these cases (22 Rust tests total).

Version1 source snapshot and artifacts remain under revisions/v1-20261006 and older
runs. Version2 does not silently migrate or overwrite old records/databases; replay
retained scenario inputs into a fresh explicit database. Artifact schema1 and native
intake schema1 stay unchanged. Source review/qualification evidence is separate from
product acceptance. Review receipts: evidence/independent-review-v1.json.
## Current revision: prototype0.1.2 / Record schema2
A second independent recheck found a catalog CAS history-replacement gap. The
transaction now compares exact artifact/policy identity and requires incoming
history to extend the stored prefix; it validates the previous body and row version
under the same write transaction. New regression preserves exact bytes of a closed
record when rejecting a higher-version divergent history, and accepts a legitimate
prefix extension on a separate record.23 Rust tests pass;15 CLI cases (6 success,
9 expected refusals) match expected outcomes. Strict Clippy, fmt check and static-CRT
Windows debug build exit0. CLI inputs require exactly5 explicit arguments and input
JSON paths must be absolute. Current paths and receipts are indexed by CURRENT.json.
Original snapshots remain unchanged. Native candidate validation is structure only;
source repair remains Proposed. No live model, continuous-loop, source or host change.