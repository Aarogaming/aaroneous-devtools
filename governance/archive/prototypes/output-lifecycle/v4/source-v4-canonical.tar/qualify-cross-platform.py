import argparse, hashlib, json, os, platform, subprocess
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--binary',type=Path,required=True)
parser.add_argument('--name',required=True)
a=parser.parse_args()
if not a.root.is_absolute() or not a.binary.is_absolute() or not a.name.isalnum():
    raise SystemExit('explicit absolute paths and alphanumeric run name required')
run=a.root/'runs'/a.name
run.mkdir(parents=True,exist_ok=False)
checks=[]

def write(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check(name,args,expected=0):
    command=[str(a.binary),*map(str,args)]
    result=subprocess.run(command,capture_output=True,timeout=30)
    log=run/(name+'.log')
    log.write_bytes(result.stdout+result.stderr)
    checks.append(dict(name=name,command=command,exit_code=result.returncode,expected_exit=expected,log=str(log),log_sha256=sha(log)))
    write(run/'receipts.json',checks)
    if result.returncode!=expected:
        raise RuntimeError(f'{name}: expected {expected}, observed {result.returncode}: {result.stderr!r}')
proof=run/'proof.json'
write(proof,{'kind':'synthetic qualification evidence','does_not_prove_product_behavior':True})
ref=dict(path=str(proof),sha256=sha(proof))
artifact=dict(schema_version=1,id='qualification-fixture',kind='synthetic_finding',producer='fixture-worker',contributors=[],source_revision='synthetic-fixture-v4',original_verdict='synthetic rejected brief',profile='prototype_tooling',evidence=[ref])
binding=hashlib.sha256(json.dumps(artifact,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
review=dict(reviewer='fixture-reviewer',artifact_sha256=binding,action_sha256=None,disposition='follow_up',scope='synthetic lifecycle qualification only',note='No product behavior or actual repair claim',receipt=ref)
scenario=dict(artifact=artifact,events=[dict(expected_version=0,tick=1,operation=dict(type='review',review=review)),dict(expected_version=1,tick=2,operation=dict(type='plan',task='Synthetic bounded qualification action',acceptance='Synthetic fixture bytes match',destination='steward-candidate-inbox'))])
scenario_path=run/'scenario.json';write(scenario_path,scenario)
observation=run/'model.json'
write(observation,{'proposal':'Do not trust this model text','operation':'delete_cache','command':'never execute model commands'})
observation_ref=run/'model-reference.json';write(observation_ref,dict(path=str(observation),sha256=sha(observation)))
host=dict(intake_root=str(run),output_root=str(run),allowed_reads=[str(proof),str(observation)],policy=dict(max_attempts=2,max_lease_ticks=6),catalog_capacity=4)
host_path=run/'host.json';write(host_path,host)
db=run/'catalog.db';ready=run/'ready.json'
check('replay',['replay',host_path,scenario_path,db,ready])
check('repeat-identical',['replay',host_path,scenario_path,db,ready])
check('resume-after-catalog-commit',['replay',host_path,scenario_path,db,run/'recovered.json'])
check('catalog-search',['catalog',host_path,'synthetic',db,run/'search.json'])
check('empty-search',['catalog',host_path,'not-found',db,run/'empty.json'])
check('export',['export',host_path,'qualification-fixture',db,run/'intake.json'])
check('observe',['observe',host_path,observation_ref,'-',run/'observation.json'])
check('extra-argument',['catalog',host_path,'-',db,run/'extra.json','extra'],1)
check('unknown-option',['delete_cache',host_path,'-',db,run/'unknown.json'],1)
check('missing-record',['export',host_path,'missing',db,run/'missing.json'],1)
check('outside-output',['catalog',host_path,'-',db,a.root/'outside.json'],1)
check('dot-traversal',['catalog',host_path,'-',db,str(run)+'/../escaped.json'],1)
check('reserved-stage-name',['catalog',host_path,'-',db,run/'.prepared-forbidden'],1)
for name,mutate in [('stale-hash',lambda s:s['artifact']['evidence'][0].update(sha256='0'*64)),('self-review',lambda s:s['events'][0]['operation']['review'].update(reviewer='fixture-worker')),('unknown-field',lambda s:s.update(unrecognized=True))]:
    bad=json.loads(json.dumps(scenario));mutate(bad)
    path=run/(name+'.json');write(path,bad)
    check(name,['replay',host_path,path,run/(name+'.db'),run/(name+'-out.json')],1)
    assert not (run/(name+'.db')).exists(), 'rejected input opened a catalog'
unapproved=json.loads(json.dumps(host));unapproved['allowed_reads']=[]
write(run/'unapproved-host.json',unapproved)
check('unapproved-read',['replay',run/'unapproved-host.json',scenario_path,run/'unapproved.db',run/'unapproved-out.json'],1)
assert not (run/'unapproved.db').exists()
collision=run/'collision.json';collision.write_bytes(b'original retained bytes');original=sha(collision)
check('output-collision',['replay',host_path,scenario_path,run/'collision.db',collision],1)
assert sha(collision)==original and not (run/'collision.db').exists()
oversized=run/'oversized.json';oversized.write_bytes(b' '*2_097_153)
check('oversized-input',['replay',host_path,oversized,run/'oversized.db',run/'oversized-out.json'],1)
assert not (run/'oversized.db').exists()
longhost=json.loads(json.dumps(host));longhost['catalog_capacity']=257
write(run/'oversized-capacity-host.json',longhost)
check('oversized-capacity',['catalog',run/'oversized-capacity-host.json','-',run/'capacity.db',run/'capacity-out.json'],1)
assert not (run/'capacity.db').exists()
partial=run/'partial.json'
raw=observation.read_bytes();payload=json.loads(raw)
value=dict(schema_version=1,kind='model_observation',source=dict(path=str(observation),sha256=sha(observation)),accepted=False,product_verified=False,observation=payload)
# Derive Rust's pretty JSON bytes for the staged output from an already successful publication.
bytes_expected=(run/'observation.json').read_bytes()
key=json.dumps([partial.name,hashlib.sha256(bytes_expected).hexdigest()],separators=(',',':')).encode()
stage=run/('.prepared-'+hashlib.sha256(key).hexdigest());stage.write_bytes(b'interrupted partial fixture')
check('partial-preparation',['observe',host_path,observation_ref,'-',partial],1)
assert not partial.exists() and stage.read_bytes()==b'interrupted partial fixture'
check('new-path-recovery',['observe',host_path,observation_ref,'-',run/'new-path.json'])
assert json.loads((run/'new-path.json').read_text())['accepted'] is False
symlink={'status':'not-exercised','reason':'platform lacks permission'}
outside=a.root/('outside-'+a.name);outside.mkdir()
try:
    os.symlink(outside,run/'escape',target_is_directory=True)
except OSError as e:
    symlink['reason']=str(e)
else:
    check('symlink-escape',['catalog',host_path,'-',db,run/'escape'/'out.json'],1)
    assert not (outside/'out.json').exists()
    symlink={'status':'exercised-refusal'}
for name in ['extra.json','unknown.json','missing.json','escaped.json','unapproved-out.json','capacity-out.json','oversized-out.json']:
    assert not (run/name).exists(),f'rejected route created {name}'
assert len(json.loads((run/'search.json').read_text())['records'])==1
assert len(json.loads((run/'empty.json').read_text())['records'])==0
assert json.loads((run/'observation.json').read_text())['product_verified'] is False
write(run/'summary.json',dict(checks=len(checks),expected_refusals=sum(c['expected_exit']==1 for c in checks),all_expected=True,platform=platform.platform(),binary_sha256=sha(a.binary),symlink=symlink,synthetic_inputs=True,source_repair_executed=False,product_verified=False))
print(run)
print(f'All {len(checks)} portable CLI cases matched expected outcomes.')
