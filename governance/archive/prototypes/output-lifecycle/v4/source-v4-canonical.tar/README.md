# Output lifecycle prototype

Status: isolated runtime prototype, not an official devtools or Aaroneous feature.
Owner requested modular prototyping on 2026-10-06 EDT. This experiment adds the
consumption contract next to the existing Rig experiment; it does not dispatch jobs.

## What runs

* Rust pure reducer: review, one action, leases, receipt, challenge, bounded retry,
  deferral and independent scoped closure. Explicit logical ticks and version checks.
* Replaceable Stage, Catalog, ModelObservation and IntakeAdapter traits.
* SQLite catalog through rusqlite: ID lookup, metadata text search, bounded listing,
  transactional compare-and-set and reopen. Retained scenario files rebuild it.
* File observation adapter consumes an existing Rig output with its SHA256. It
  preserves accepted=false and product_verified=false; it never interprets model
  text as an operation or independent review.
* Existing native foundation validate-intake validates exported candidate packets.
  Validation is structural. The steward has not admitted or dispatched the packet.

Real historical M01 is in runs/M01-scenario.json and runs/M01-ready.json. Original
Qwen rejection is preserved. Only the review's useful semantic-count finding was
extracted: 79 lexical markers versus the model's 72. Source currentness, execution,
coverage and product conformance are not inferred from that historical record.
The record is FollowUp/action Proposed, not a completed repair.

## Manual options

All arguments are explicit; see host.json. Invoke target/debug/output-lifecycle-prototype.exe:

    replay <host.json> <scenario.json> <catalog.db> <record.json>
    catalog <host.json> <query-or-dash> <catalog.db> <catalog.json>
    export <host.json> <artifact-id> <catalog.db> <candidate.json>
    observe <host.json> <evidence-reference.json> - <observation.json>

Use absolute paths. Outputs are confined to the injected output_root. Evidence
paths must exactly match allowed_reads. Every operation checks retained evidence
hashes. Evidence references mean historic bytes, not current original-source coverage.
JSON rejects unknown fields/options and reads/writes have byte limits. Existing
nonidentical outputs are never overwritten. Exact replay is idempotent; a changed
scenario for an existing ID requires a separately retained revision/catalog. Catalog
CAS supports host-driven updates behind the trait; CLI is intentionally replay-only.

This version stores small bounded projections (maximum 256 records); metadata
search scans those projections. Original bodies and full-text/vector search are
not duplicated in the catalog. Graph relationships/petgraph are deferred until a
real graph query is needed, preserving C101/C102/C108 ownership.

## Repeatable handoff

1. Retain model result, capture and review sidecar.
2. Host explicitly extracts a finding; preserve the original whole-output verdict.
3. Review that exact artifact binding, declare one task and acceptance condition.
4. Export candidate and invoke existing native validate-intake (receipt retained).
5. Existing steward/coordination owner admits it, obtains current reservations and
   claims source scope. No prototype permission substitutes for that process.
6. Authorized executor records actual command, exit and log hash under its lease.
7. Independent review binds the exact action including receipts. Exit0 alone may
   be challenged for semantic failure. Retry budget exhaustion preserves deferral.

The current successful exercise stops after step4. Executed/closed lifecycle
branches are synthetic test evidence only. No M01 source repair is claimed.

## Authority and failure boundaries

Host config and scenario are trusted operator inputs, never model-generated actions.
Canonical lowercase seat IDs avoid spelling aliases, but identity is not cryptographically
authenticated. Production must reuse C100 identity/coverage authority. Reviews in
this catalog do not grant GitHub acceptance, product compliance or merge authority.

Catalog is a disposable projection, not a second canonical event log. No new hash
chain, scheduler, server, outbox consumer or publisher is implemented. Filesystem
publication failure after DB commit leaves a recoverable projection; retain the
failed output and replay to a new explicit path. Cross-file transactional publication,
crash/power-loss recovery and filesystem TOCTOU require additional qualification.
Do not delete retained artifacts to recover. Pause/leases of the primary worker,
provider, inference windows and automation are unchanged.

Library is ordinary tooling (allocation allowed), deny unsafe, no ambient clock,
environment, global runtime or thread creation. SQLite C code is confined to the
catalog adapter. Product adoption needs native-boundary admission and graduation.

## Readiness

Before official adoption: independent review, Windows and Linux evidence, complete
transitive/native admission, authenticated identity integration, cancellation and
crash/replay qualification, current steward contract compatibility, and coordinated
source claim. Land behind the existing workspace trait, inert or shadow first;
remove this origin copy only after proven replacement. Aaroneous never depends on
devtools. No graduation or rollout has occurred.

See CONTRACT.md, ADMISSION.md and evidence/ for exact outcomes including failures.

Current implementer evidence:18 Rust lifecycle/catalog tests exit0; strict all-target Clippy exit0; explicit static-CRT Windows debug build exit0.14 CLI cases matched expected outcomes (6 success,8 refusals), with collision bytes preserved and no forbidden output files. CLI harness: verify-prototype.ps1 -PrototypeRoot <absolute root>; creates a fresh qualification folder. Existing native intake validator returned structurally_valid=true/requires_owner_review=true. No new model inference, scheduler route, source repair or automatic adoption. Independent read-only review requested through the existing Review Aaroneous compliance chat.

## Review-driven v2 correction
Independent read-only review found lease-token reuse, trusted projection state and
silent capacity reduction. All three are repaired in prototype0.1.1. Record schema2
retains explicit injected policy and typed event history. Catalog reads/CAS validate
row ID/version and reconstruct the whole record through the pure reducer before
using its state. Policy cannot silently loosen. This establishes consistency, not
authenticated event provenance; protected host inputs/C100 identity remain required.
Lease tokens are unique across attempts and receipts explicitly bind their attempt.
Capacity reduction below retained count fails explicitly; records are never hidden.
Four additional regression families exercise these cases (22 Rust tests total).

Version1 source snapshot and artifacts remain under revisions/v1-20261006 and older
runs. Version2 does not silently migrate or overwrite old records/databases; replay
retained scenario inputs into a fresh explicit database. Artifact schema1 and native
intake schema1 stay unchanged. Source review/qualification evidence is separate from
product acceptance. Review receipts: evidence/independent-review-v1.json.
## Current revision: prototype0.1.2 / Record schema2
A second independent recheck found a catalog CAS history-replacement gap. The
transaction now compares exact artifact/policy identity and requires incoming
history to extend the stored prefix; it validates the previous body and row version
under the same write transaction. New regression preserves exact bytes of a closed
record when rejecting a higher-version divergent history, and accepts a legitimate
prefix extension on a separate record.23 Rust tests pass;15 CLI cases (6 success,
9 expected refusals) match expected outcomes. Strict Clippy, fmt check and static-CRT
Windows debug build exit0. CLI inputs require exactly5 explicit arguments and input
JSON paths must be absolute. Current paths and receipts are indexed by CURRENT.json.
Original snapshots remain unchanged. Native candidate validation is structure only;
source repair remains Proposed. No live model, continuous-loop, source or host change.
## Hardening revision 0.1.3 (v4; qualification in progress)
Catalog reads/listing now use one deferred transaction snapshot. Native SQLite row
lengths are capped before Rust deserialization; borrowed text replaces unbounded
String extraction. CAS rechecks capacity within its write transaction. SQLite
auxiliary workers and hidden busy retries are disabled; contention is surfaced to
the injected caller. Three new regression cases cover oversized rows, concurrent
capacity change, and a reader retaining one snapshot across a separate writer.

JSON publication uses an explicitly acquired cap-std directory handle. Prepared
bytes are synced, then hard-linked into a final name without replacement. Complete
prepared bytes can resume; an interrupted partial preparation is retained and
requires a new explicit output path. Prepared links stay as recovery evidence;
there is no automatic deletion. Four Windows fault/boundary cases cover pre-link
and post-link interruption, partial bytes/collisions and path/name refusal. Unix
adds a symlink-escape case. This demonstrates injected interruption behavior and
atomic name visibility on the exercised filesystem, not power-loss durability.

The capability protects relative JSON publication after bootstrap acquisition.
Root/config integrity remains operator-owned. SQLite still opens its explicit path
through its existing native VFS; catalog directory acquisition races and hostile
same-user mutation remain production blockers. No custom SQLite VFS is added.

Windows:30 Rust tests, strict all-target Clippy, formatting and explicit static-CRT
build exit0;15 historical M01 CLI cases and22 portable synthetic cases exit0. The
first v4 Clippy run failed101 (collapsible conditional); its log is retained and the
conditional was corrected without suppressing the lint. Linux and independent v4
qualification are pending. Independent frozen v3 execution passed23 tests/15CLI.
Portable harness is retained as evidence/qualify-cross-platform.py, not a second
runtime pipeline. Declared Rust floor1.98 has Windows1.98.1 evidence; Ubuntu's
existing1.99.0 toolchain is being used without installation or settings changes.
