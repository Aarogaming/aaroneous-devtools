param([Parameter(Mandatory=$true)][string]$PrototypeRoot)
$ErrorActionPreference='Stop'
$utf8=[Text.UTF8Encoding]::new($false)
$runRoot=Join-Path $PrototypeRoot ('runs/qualification-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssffffZ'))
New-Item -ItemType Directory -Path $runRoot | Out-Null
$binary=Join-Path $PrototypeRoot 'target/debug/output-lifecycle-prototype.exe'
$hostFile=Join-Path $PrototypeRoot 'host.json'
$scenario=Get-Content -LiteralPath (Join-Path $PrototypeRoot 'runs/M01-scenario.json') -Raw | ConvertFrom-Json -AsHashtable
$checks=[Collections.Generic.List[object]]::new()
function Write-Json([string]$path,$value){[IO.File]::WriteAllText($path,($value|ConvertTo-Json -Depth 40),$utf8)}
function Check([string]$name,[string[]]$arguments,[int]$expected=0) {
    $log=Join-Path $runRoot ($name+'.log')
    & $binary @arguments *> $log
    $actual=$LASTEXITCODE
    $checks.Add(@{name=$name;executable=$binary;arguments=$arguments;exit_code=$actual;expected_exit=$expected;log=$log})
    Write-Json (Join-Path $runRoot 'receipts.json') $checks.ToArray()
    if($actual -ne $expected){throw "Unexpected exit for $name : $actual"}
}
$db=Join-Path $runRoot 'catalog.db'
$output=Join-Path $runRoot 'ready.json'
Check 'replay' @('replay',$hostFile,(Join-Path $PrototypeRoot 'runs/M01-scenario.json'),$db,$output)
Check 'repeat-identical' @('replay',$hostFile,(Join-Path $PrototypeRoot 'runs/M01-scenario.json'),$db,$output)
Check 'search' @('catalog',$hostFile,'lexical',$db,(Join-Path $runRoot 'search.json'))
Check 'empty-search' @('catalog',$hostFile,'no-such-record',$db,(Join-Path $runRoot 'empty.json'))
Check 'export' @('export',$hostFile,'M01-reviewed-semantic-count',$db,(Join-Path $runRoot 'intake.json'))
Check 'extra-argument' @('catalog',$hostFile,'-',$db,(Join-Path $runRoot 'extra.json'),'unexpected') 1
Check 'unknown-option' @('delete_cache',$hostFile,'-',$db,(Join-Path $runRoot 'unknown.json')) 1
$bad=$scenario|ConvertTo-Json -Depth 40|ConvertFrom-Json -AsHashtable
$bad.artifact.evidence[0].sha256='0'*64
Write-Json (Join-Path $runRoot 'stale.json') $bad
Check 'stale-evidence' @('replay',$hostFile,(Join-Path $runRoot 'stale.json'),(Join-Path $runRoot 'stale.db'),(Join-Path $runRoot 'stale-out.json')) 1
$bad=$scenario|ConvertTo-Json -Depth 40|ConvertFrom-Json -AsHashtable
$bad.events[0].operation.review.reviewer='qwen'
Write-Json (Join-Path $runRoot 'self-review.json') $bad
Check 'self-review' @('replay',$hostFile,(Join-Path $runRoot 'self-review.json'),(Join-Path $runRoot 'self.db'),(Join-Path $runRoot 'self-out.json')) 1
$badHost=Get-Content -LiteralPath $hostFile -Raw|ConvertFrom-Json -AsHashtable
$badHost.allowed_reads=@()
Write-Json (Join-Path $runRoot 'unapproved-host.json') $badHost
Check 'unapproved-read' @('replay',(Join-Path $runRoot 'unapproved-host.json'),(Join-Path $PrototypeRoot 'runs/M01-scenario.json'),(Join-Path $runRoot 'unapproved.db'),(Join-Path $runRoot 'unapproved-out.json')) 1
$collision=Join-Path $runRoot 'collision.json'
Write-Json $collision @{preserve='original fixture'}
$before=(Get-FileHash -LiteralPath $collision -Algorithm SHA256).Hash
Check 'collision-preserved' @('replay',$hostFile,(Join-Path $PrototypeRoot 'runs/M01-scenario.json'),(Join-Path $runRoot 'collision.db'),$collision) 1
if($before -ne (Get-FileHash -LiteralPath $collision -Algorithm SHA256).Hash){throw 'Collision original changed'}
Check 'outside-write' @('catalog',$hostFile,'-',$db,(Join-Path $PrototypeRoot 'outside-output.json')) 1
Check 'dot-traversal' @('catalog',$hostFile,'-',$db,($runRoot+'/../escape.json')) 1
Check 'missing-record' @('export',$hostFile,'missing',$db,(Join-Path $runRoot 'missing.json')) 1
Check 'rig-observation' @('observe',$hostFile,(Join-Path $PrototypeRoot 'runs/rig-evidence.json'),'-',(Join-Path $runRoot 'rig.json'))
$rig=Get-Content -LiteralPath (Join-Path $runRoot 'rig.json') -Raw|ConvertFrom-Json
if($rig.accepted -ne $false -or $rig.product_verified -ne $false){throw 'Model output gained authority'}
if(@((Get-Content -LiteralPath (Join-Path $runRoot 'search.json') -Raw|ConvertFrom-Json).records).Count -ne 1){throw 'Search projection wrong'}
if(@((Get-Content -LiteralPath (Join-Path $runRoot 'empty.json') -Raw|ConvertFrom-Json).records).Count -ne 0){throw 'Empty search wrong'}
foreach($name in @('stale.db','self.db','unapproved.db','collision.db','unknown.json','missing.json','stale-out.json','self-out.json','unapproved-out.json')) {
    if(Test-Path -LiteralPath (Join-Path $runRoot $name)){throw "Failed route mutated output $name"}
}
Write-Json (Join-Path $runRoot 'summary.json') @{checks=$checks.Count;expected_refusals=@($checks|Where-Object expected_exit -eq 1).Count;all_expected=$true;synthetic_negative_fixtures=$true;real_model_inference=$false;original_repair_executed=$false;product_verified=$false;binary_sha256=(Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash}
Write-Output $runRoot
Write-Output "All $($checks.Count) CLI routes matched their expected outcome."
